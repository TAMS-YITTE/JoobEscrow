// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

// Mock token avec fee-on-transfer (3% de frais)
contract MockFeeToken is ERC20 {
    uint256 public constant FEE_PERCENT = 3;
    
    constructor() ERC20("Fee Token", "FEE") {
        _mint(msg.sender, 1000000 * 10**18);
    }
    
    function transfer(address to, uint256 amount) public override returns (bool) {
        uint256 fee = (amount * FEE_PERCENT) / 100;
        uint256 netAmount = amount - fee;
        super.transfer(to, netAmount);
        return true;
    }
    
    function transferFrom(address from, address to, uint256 amount) public override returns (bool) {
        uint256 fee = (amount * FEE_PERCENT) / 100;
        uint256 netAmount = amount - fee;
        super.transferFrom(from, to, netAmount);
        return true;
    }
}
