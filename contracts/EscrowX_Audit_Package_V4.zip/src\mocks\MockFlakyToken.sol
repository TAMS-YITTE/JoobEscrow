// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

// Mock token qui revert aléatoirement (simule un token problématique)
contract MockFlakyToken is ERC20 {
    bool public shouldRevert = true;
    
    constructor() ERC20("Flaky Token", "FLKY") {
        _mint(msg.sender, 1000000 * 10**18);
    }
    
    function setRevert(bool _revert) external {
        shouldRevert = _revert;
    }
    
    function transfer(address to, uint256 amount) public override returns (bool) {
        if (shouldRevert) revert("Random failure");
        return super.transfer(to, amount);
    }
}
