// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title UniversalServiceEscrow
 * @notice Moteur d'escrow générique pour prestations de services (BNB Smart Chain).
 *
 * Durcissements par rapport à la v2 :
 *  1. Pull-over-push   : les fonds sont CRÉDITÉS puis retirés par le bénéficiaire (withdraw),
 *                        jamais poussés. Neutralise le griefing par réception (revert / blacklist).
 *  2. Ownable2Step     : transfert de propriété en deux temps (anti-faute de frappe fatale).
 *  3. Invariant compta : totalLocked + totalWithdrawable. La récupération de tokens "coincés"
 *                        ne peut JAMAIS toucher les fonds dus -> drain impossible par l'admin.
 *  4. Dispute non-binaire : résolution par split (provider 0..100%), pas seulement tout-ou-rien.
 *  5. Ancrage de preuves : evidenceHash (CID IPFS) horodaté on-chain à l'ouverture du litige
 *                          et via submitEvidence, par les deux parties.
 *  6. Acceptation provider : tant que non accepté, le client peut annuler librement ;
 *                            après acceptation, l'annulation passe par un litige.
 *  7. Limites PAR TOKEN  : min/max stockés par token (gère les décimales hétérogènes).
 *  8. Timelock           : fee, feeRecipient et limites globales passent par une file 24-48h.
 *  9. Pause d'urgence    : conserve la création/release/cancel sous whenNotPaused, mais withdraw
 *                          et resolveDispute restent accessibles (choix conscient, cf. commentaires).
 *
 * Modifications V3 :
 *  - Bug du symbole lors du delete réglé.
 *  - Ajout du minTimeoutDays (défaut 3 jours).
 *  - openDispute et submitEvidence sortis du whenNotPaused.
 *  - Ajout de acceptDelaySeconds (optionnel, 0 par défaut).
 *  - Ajout de batchWithdraw.
 */

import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

contract UniversalServiceEscrow is ReentrancyGuard, Ownable2Step {

    using SafeERC20 for IERC20;

    // --- Types ---

    enum Status { NULL, FUNDED, RELEASED, DISPUTED, RESOLVED, CANCELLED }

    struct Escrow {
        address client;
        address provider;
        address token;
        uint256 amount;
        uint256 feeBPS;          // commission figée à la création
        uint256 createdAt;       // date de création (pour acceptDelay)
        uint256 timeoutDate;
        Status  status;
        bool    accepted;        // le provider a accepté la mission
    }

    struct TokenConfig {
        bool    allowed;
        string  symbol;
        uint256 minAmount;       // bornes PAR token (décimales propres au token)
        uint256 maxAmount;
    }

    // --- Storage ---

    uint256 public escrowCounter;
    mapping(uint256 => Escrow) public escrows;

    mapping(address => uint256) public activeEscrowsByUser;     // client => nb d'escrows actifs
    mapping(address => TokenConfig) public tokenConfigs;

    // Pull-over-push
    mapping(address => mapping(address => uint256)) public withdrawable; // user => token => montant
    mapping(address => uint256) public totalWithdrawable;                // token => somme due
    mapping(address => uint256) public totalLocked;                      // token => somme bloquée en escrow

    bool public paused;

    address public feeRecipient;
    uint256 public defaultFeeBPS         = 800;   // 8%
    uint256 public maxActiveEscrowsPerUser = 10;
    uint256 public minTimeoutDays        = 3;     // Minimum 3 jours pour protéger le client
    uint256 public maxTimeoutDays        = 365;
    uint256 public acceptDelaySeconds    = 0;     // Délai optionnel avant acceptation

    uint256 public staleDisputeTimeout   = 30 days;
    mapping(uint256 => uint256) public disputeOpenedAt;

    // Timelock
    uint256 public constant TIMELOCK_DELAY = 2 days;
    mapping(bytes32 => uint256) public timelocks; // actionId => earliest execution timestamp

    // Pré-whitelist BNB Smart Chain (18 décimales pour les 4)
    address public constant BUSD = 0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56;
    address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    address public constant USDC = 0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d;
    address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;

    // --- Events ---

    event EscrowCreated(uint256 indexed escrowId, address indexed client, address indexed provider, address token, uint256 amount, uint256 timeoutDate);
    event EscrowAccepted(uint256 indexed escrowId, address indexed provider);
    
    // Note indexeur : FundsReleased est l'event comptable unique pour les paiements réussis.
    // TimeoutClaimed est émis EN PLUS de FundsReleased pour indiquer la raison spécifique du déblocage.
    event FundsReleased(uint256 indexed escrowId, uint256 providerAmount, uint256 feeAmount);
    event TimeoutClaimed(uint256 indexed escrowId, address indexed provider);
    
    event EscrowCancelled(uint256 indexed escrowId, address indexed client, uint256 amount);
    event DisputeOpened(uint256 indexed escrowId, address indexed opener, bytes32 evidenceHash);
    event EvidenceSubmitted(uint256 indexed escrowId, address indexed party, bytes32 evidenceHash);
    event DisputeResolved(uint256 indexed escrowId, uint256 providerBps, uint256 providerAmount, uint256 clientAmount, uint256 feeAmount);
    event StaleDisputeResolved(uint256 indexed escrowId, address resolver, uint256 clientAmount);
    event Credited(address indexed user, address indexed token, uint256 amount);
    event Withdrawn(address indexed user, address indexed token, uint256 amount);
    event TokensRecovered(address indexed token, address indexed to, uint256 amount);

    event TokenConfigUpdated(address indexed token, bool allowed, string symbol, uint256 minAmount, uint256 maxAmount);
    event FeeRecipientUpdated(address indexed oldRecipient, address indexed newRecipient);
    event DefaultFeeUpdated(uint256 oldFee, uint256 newFee);
    event LimitsUpdated(uint256 maxActive, uint256 minTimeout, uint256 maxTimeout, uint256 acceptDelay);
    event PauseToggled(bool paused);
    event ActionQueued(bytes32 indexed actionId, uint256 executeAfter);
    event ActionCancelled(bytes32 indexed actionId);

    // --- Constructor ---

    constructor(address _feeRecipient) Ownable(msg.sender) {
        require(_feeRecipient != address(0), "Invalid fee recipient");
        feeRecipient = _feeRecipient;

        // Auto-whitelist only on BSC Mainnet (ChainID 56)
        if (block.chainid == 56) {
            if (BUSD.code.length > 0) _whitelistToken(BUSD, "BUSD", 1 ether, 100000 ether);
            if (USDT.code.length > 0) _whitelistToken(USDT, "USDT", 1 ether, 100000 ether);
            if (USDC.code.length > 0) _whitelistToken(USDC, "USDC", 1 ether, 100000 ether);
            if (WBNB.code.length > 0) _whitelistToken(WBNB, "WBNB", 0.01 ether, 1000 ether);
        }
    }

    // --- Modifiers ---

    modifier whenNotPaused() {
        require(!paused, "Contract is paused");
        _;
    }

    // --- Admin : tokens (immédiat, owner-gated) ---

    function setTokenAllowed(
        address _token,
        string calldata _symbol,
        uint256 _minAmount,
        uint256 _maxAmount,
        bool _allowed
    ) external onlyOwner {
        require(_token != address(0), "Invalid token address");
        require(_token.code.length > 0, "Not a contract");

        if (_allowed) {
            require(_minAmount > 0, "Min must be > 0");
            require(_maxAmount > _minAmount, "Max must be > min");
            _whitelistToken(_token, _symbol, _minAmount, _maxAmount);
        } else {
            string memory oldSymbol = tokenConfigs[_token].symbol;
            delete tokenConfigs[_token];
            emit TokenConfigUpdated(_token, false, oldSymbol, 0, 0);
        }
    }

    function _whitelistToken(address _token, string memory _symbol, uint256 _min, uint256 _max) internal {
        try IERC20(_token).totalSupply() returns (uint256 supply) {
            require(supply > 0, "Token has no supply");
            tokenConfigs[_token] = TokenConfig({allowed: true, symbol: _symbol, minAmount: _min, maxAmount: _max});
            emit TokenConfigUpdated(_token, true, _symbol, _min, _max);
        } catch {
            revert("Invalid BEP-20 token");
        }
    }

    // --- Admin : pause (immédiat, c'est le but d'un coupe-circuit) ---

    function togglePause() external onlyOwner {
        paused = !paused;
        emit PauseToggled(paused);
    }

    // --- Admin : paramètres critiques sous timelock ---

    function _queue(bytes32 actionId) internal {
        uint256 executeAfter = block.timestamp + TIMELOCK_DELAY;
        timelocks[actionId] = executeAfter;
        emit ActionQueued(actionId, executeAfter);
    }

    function _consume(bytes32 actionId) internal {
        uint256 t = timelocks[actionId];
        require(t != 0, "Action not queued");
        require(block.timestamp >= t, "Timelock not elapsed");
        delete timelocks[actionId];
    }

    function cancelQueuedAction(bytes32 actionId) external onlyOwner {
        require(timelocks[actionId] != 0, "Nothing queued");
        delete timelocks[actionId];
        emit ActionCancelled(actionId);
    }

    // Fee
    function queueDefaultFee(uint256 _newFeeBPS) external onlyOwner {
        require(_newFeeBPS <= 2000, "Fee too high (max 20%)");
        _queue(keccak256(abi.encode("FEE", _newFeeBPS)));
    }
    function executeDefaultFee(uint256 _newFeeBPS) external onlyOwner {
        _consume(keccak256(abi.encode("FEE", _newFeeBPS)));
        uint256 old = defaultFeeBPS;
        defaultFeeBPS = _newFeeBPS;
        emit DefaultFeeUpdated(old, _newFeeBPS);
    }

    // Fee recipient
    function queueFeeRecipient(address _newRecipient) external onlyOwner {
        require(_newRecipient != address(0), "Invalid address");
        _queue(keccak256(abi.encode("RECIPIENT", _newRecipient)));
    }
    function executeFeeRecipient(address _newRecipient) external onlyOwner {
        _consume(keccak256(abi.encode("RECIPIENT", _newRecipient)));
        address old = feeRecipient;
        feeRecipient = _newRecipient;
        emit FeeRecipientUpdated(old, _newRecipient);
    }

    // Limites globales
    function queueLimits(uint256 _maxActive, uint256 _minTimeout, uint256 _maxTimeout, uint256 _acceptDelay) external onlyOwner {
        require(_maxActive > 0, "Max active must be > 0");
        require(_minTimeout > 0, "Min timeout must be > 0");
        require(_maxTimeout > _minTimeout, "Invalid timeout range");
        require(_maxTimeout <= 730, "Timeout exceeds absolute max");
        _queue(keccak256(abi.encode("LIMITS", _maxActive, _minTimeout, _maxTimeout, _acceptDelay)));
    }
    function executeLimits(uint256 _maxActive, uint256 _minTimeout, uint256 _maxTimeout, uint256 _acceptDelay) external onlyOwner {
        _consume(keccak256(abi.encode("LIMITS", _maxActive, _minTimeout, _maxTimeout, _acceptDelay)));
        require(_minTimeout > 0, "Min timeout must be > 0");
        maxActiveEscrowsPerUser = _maxActive;
        minTimeoutDays = _minTimeout;
        maxTimeoutDays = _maxTimeout;
        acceptDelaySeconds = _acceptDelay;
        emit LimitsUpdated(_maxActive, _minTimeout, _maxTimeout, _acceptDelay);
    }

    // Stale timeout
    function queueStaleTimeout(uint256 _newTimeoutDays) external onlyOwner {
        require(_newTimeoutDays >= 7, "Stale timeout must be at least 7 days");
        require(_newTimeoutDays <= 90, "Stale timeout max 90 days");
        _queue(keccak256(abi.encode("STALE_TIMEOUT", _newTimeoutDays)));
    }
    function executeStaleTimeout(uint256 _newTimeoutDays) external onlyOwner {
        _consume(keccak256(abi.encode("STALE_TIMEOUT", _newTimeoutDays)));
        staleDisputeTimeout = _newTimeoutDays * 1 days;
    }

    // --- Core : création ---

    function createAndFundEscrow(
        address _provider,
        address _token,
        uint256 _amount,
        uint256 _timeoutDurationInDays
    ) external nonReentrant whenNotPaused returns (uint256) {
        TokenConfig memory cfg = tokenConfigs[_token];
        require(cfg.allowed, "Token not whitelisted");
        require(_provider != address(0), "Invalid provider");
        require(_provider != msg.sender, "Provider cannot be client");
        require(_amount >= cfg.minAmount, "Amount below minimum");
        require(_amount <= cfg.maxAmount, "Amount above maximum");
        require(_timeoutDurationInDays >= minTimeoutDays, "Timeout below minimum");
        require(_timeoutDurationInDays <= maxTimeoutDays, "Timeout exceeds maximum");
        require(activeEscrowsByUser[msg.sender] < maxActiveEscrowsPerUser, "Too many active escrows");

        // Mesure réelle reçue (gère le fee-on-transfer)
        uint256 balanceBefore = IERC20(_token).balanceOf(address(this));
        IERC20(_token).safeTransferFrom(msg.sender, address(this), _amount);
        uint256 actualAmount = IERC20(_token).balanceOf(address(this)) - balanceBefore;
        require(actualAmount > 0, "Transfer returned 0 tokens");

        uint256 escrowId = ++escrowCounter;
        uint256 timeoutDate = block.timestamp + (_timeoutDurationInDays * 1 days);

        escrows[escrowId] = Escrow({
            client: msg.sender,
            provider: _provider,
            token: _token,
            amount: actualAmount,
            feeBPS: defaultFeeBPS,
            createdAt: block.timestamp,
            timeoutDate: timeoutDate,
            status: Status.FUNDED,
            accepted: false
        });

        activeEscrowsByUser[msg.sender]++;
        totalLocked[_token] += actualAmount;

        emit EscrowCreated(escrowId, msg.sender, _provider, _token, actualAmount, timeoutDate);
        return escrowId;
    }

    // --- Core : acceptation provider ---

    function acceptEscrow(uint256 _escrowId) external whenNotPaused {
        Escrow storage e = escrows[_escrowId];
        require(msg.sender == e.provider, "Only provider can accept");
        require(e.status == Status.FUNDED, "Escrow not in FUNDED state");
        require(block.timestamp >= e.createdAt + acceptDelaySeconds, "Accept delay not met");
        require(!e.accepted, "Already accepted");
        e.accepted = true;
        emit EscrowAccepted(_escrowId, msg.sender);
    }

    // --- Core : happy path ---

    function releaseFunds(uint256 _escrowId) external nonReentrant whenNotPaused {
        Escrow storage e = escrows[_escrowId];
        require(msg.sender == e.client, "Only client can release");
        require(e.status == Status.FUNDED, "Escrow not in FUNDED state");

        e.status = Status.RELEASED;
        activeEscrowsByUser[e.client]--;

        uint256 feeAmount = (e.amount * e.feeBPS) / 10000;
        uint256 providerAmount = e.amount - feeAmount;

        totalLocked[e.token] -= e.amount;
        _credit(feeRecipient, e.token, feeAmount);
        _credit(e.provider, e.token, providerAmount);

        emit FundsReleased(_escrowId, providerAmount, feeAmount);
    }

    function claimTimeout(uint256 _escrowId) external nonReentrant whenNotPaused {
        Escrow storage e = escrows[_escrowId];
        require(msg.sender == e.provider, "Only provider can claim timeout");
        require(e.status == Status.FUNDED, "Escrow not in FUNDED state");
        require(block.timestamp > e.timeoutDate, "Timeout not reached yet");

        e.status = Status.RELEASED;
        activeEscrowsByUser[e.client]--;

        uint256 feeAmount = (e.amount * e.feeBPS) / 10000;
        uint256 providerAmount = e.amount - feeAmount;

        totalLocked[e.token] -= e.amount;
        _credit(feeRecipient, e.token, feeAmount);
        _credit(e.provider, e.token, providerAmount);

        emit TimeoutClaimed(_escrowId, msg.sender);
        emit FundsReleased(_escrowId, providerAmount, feeAmount);
    }

    // --- Core : annulation (uniquement avant acceptation) ---

    function cancelEscrow(uint256 _escrowId) external nonReentrant whenNotPaused {
        Escrow storage e = escrows[_escrowId];
        require(msg.sender == e.client, "Only client can cancel");
        require(e.status == Status.FUNDED, "Escrow not in FUNDED state");
        require(!e.accepted, "Provider accepted: open a dispute instead");

        e.status = Status.CANCELLED;
        activeEscrowsByUser[e.client]--;

        totalLocked[e.token] -= e.amount;
        _credit(e.client, e.token, e.amount); // remboursement intégral, pas de fee

        emit EscrowCancelled(_escrowId, e.client, e.amount);
    }

    // --- Litiges ---

    function openDispute(uint256 _escrowId, bytes32 _evidenceHash) external nonReentrant {
        Escrow storage e = escrows[_escrowId];
        require(msg.sender == e.client || msg.sender == e.provider, "Not party to escrow");
        require(e.status == Status.FUNDED, "Escrow not in FUNDED state");

        e.status = Status.DISPUTED;
        disputeOpenedAt[_escrowId] = block.timestamp;
        emit DisputeOpened(_escrowId, msg.sender, _evidenceHash);
    }

    function submitEvidence(uint256 _escrowId, bytes32 _evidenceHash) external {
        Escrow storage e = escrows[_escrowId];
        require(msg.sender == e.client || msg.sender == e.provider, "Not party to escrow");
        require(e.status == Status.DISPUTED, "Escrow not in DISPUTED state");
        emit EvidenceSubmitted(_escrowId, msg.sender, _evidenceHash);
    }

    /**
     * @notice Résolution par split. _providerBps = part du provider sur 10000.
     *         10000 = provider gagne tout, 0 = client remboursé intégralement.
     *         La commission n'est prélevée QUE sur la part attribuée au provider.
     * @dev    NON soumis à whenNotPaused : un litige en cours doit pouvoir être tranché
     *         même si le contrat est en pause pour une raison non liée.
     */
    function resolveDispute(uint256 _escrowId, uint256 _providerBps) external onlyOwner nonReentrant {
        require(_providerBps <= 10000, "Invalid split");
        Escrow storage e = escrows[_escrowId];
        require(e.status == Status.DISPUTED, "Escrow not in DISPUTED state");

        uint256 providerShare = (e.amount * _providerBps) / 10000;
        uint256 clientShare = e.amount - providerShare;

        uint256 feeAmount = (providerShare * e.feeBPS) / 10000;
        uint256 providerNet = providerShare - feeAmount;

        e.status = Status.RESOLVED;
        activeEscrowsByUser[e.client]--;
        totalLocked[e.token] -= e.amount;
        delete disputeOpenedAt[_escrowId];

        _credit(feeRecipient, e.token, feeAmount);
        _credit(e.provider, e.token, providerNet);
        _credit(e.client, e.token, clientShare);

        emit DisputeResolved(_escrowId, _providerBps, providerNet, clientShare, feeAmount);
    }

    /**
     * @notice Permet au client ou au provider de forcer la résolution d'un litige abandonné
     *         (stale). Le remboursement se fait intégralement vers le client par défaut.
     * @dev    Le compteur n'est PAS gelé pendant une mise en pause (paused = true). 
     *         Si une pause dure trop longtemps, les litiges pourront expirer en stale.
     *         Ceci est un choix assumé pour éviter le blocage perpétuel des fonds.
     */
    function resolveStaleDispute(uint256 _escrowId) external nonReentrant {
        Escrow storage e = escrows[_escrowId];
        require(e.status == Status.DISPUTED, "Escrow not in DISPUTED state");
        require(msg.sender == e.client || msg.sender == e.provider, "Not party to escrow");
        require(block.timestamp > disputeOpenedAt[_escrowId] + staleDisputeTimeout, "Dispute is not stale yet");

        e.status = Status.RESOLVED;
        activeEscrowsByUser[e.client]--;
        totalLocked[e.token] -= e.amount;
        delete disputeOpenedAt[_escrowId];

        _credit(e.client, e.token, e.amount); // 100% refund to client, no platform fee

        emit StaleDisputeResolved(_escrowId, msg.sender, e.amount);
    }

    // --- Pull-over-push ---

    function _credit(address _user, address _token, uint256 _amount) internal {
        if (_amount == 0) return;
        withdrawable[_user][_token] += _amount;
        totalWithdrawable[_token] += _amount;
        emit Credited(_user, _token, _amount);
    }

    /**
     * @notice Retrait des fonds dus. NON soumis à whenNotPaused : un utilisateur doit
     *         toujours pouvoir sortir ses fonds (principe non-custodial). L'invariant
     *         comptable empêche tout crédit non couvert par le solde réel.
     */
    function withdraw(address _token) external nonReentrant {
        uint256 amount = withdrawable[msg.sender][_token];
        require(amount > 0, "Nothing to withdraw");

        withdrawable[msg.sender][_token] = 0;
        totalWithdrawable[_token] -= amount;

        IERC20(_token).safeTransfer(msg.sender, amount);
        emit Withdrawn(msg.sender, _token, amount);
    }

    /**
     * @notice Permet de retirer les fonds dus sur plusieurs tokens en une seule transaction.
     */
    function batchWithdraw(address[] calldata _tokens) external nonReentrant {
        for (uint256 i = 0; i < _tokens.length; i++) {
            address token = _tokens[i];
            uint256 amount = withdrawable[msg.sender][token];
            if (amount > 0) {
                withdrawable[msg.sender][token] = 0;
                totalWithdrawable[token] -= amount;
                IERC20(token).safeTransfer(msg.sender, amount);
                emit Withdrawn(msg.sender, token, amount);
            }
        }
    }

    // --- Récupération bornée (drain impossible) ---

    /**
     * @notice Ne peut récupérer QUE l'excédent : balanceOf - totalLocked - totalWithdrawable.
     *         Mathématiquement incapable de toucher aux fonds des escrows ou des soldes dus.
     */
    function recoverStuckTokens(address _token, address _to, uint256 _amount) external onlyOwner nonReentrant {
        require(_to != address(0), "Invalid recipient");
        uint256 bal = IERC20(_token).balanceOf(address(this));
        uint256 committed = totalLocked[_token] + totalWithdrawable[_token];
        require(bal > committed, "No surplus");
        require(_amount <= bal - committed, "Exceeds surplus");

        IERC20(_token).safeTransfer(_to, _amount);
        emit TokensRecovered(_token, _to, _amount);
    }

    // --- Vues ---

    function getEscrowDetails(uint256 _escrowId) external view returns (
        address client,
        address provider,
        address token,
        string memory sym,
        uint256 amount,
        uint256 feeBPS,
        uint256 timeoutDate,
        Status  status,
        bool    accepted
    ) {
        Escrow storage e = escrows[_escrowId];
        require(e.client != address(0), "Escrow does not exist");
        return (e.client, e.provider, e.token, tokenConfigs[e.token].symbol, e.amount, e.feeBPS, e.timeoutDate, e.status, e.accepted);
    }

    /**
     * @notice Vue paginée. Coûteuse en boucle : à n'appeler qu'en off-chain (eth_call).
     *         Pour du volume, indexer les events via The Graph plutôt que d'itérer ici.
     */
    function getActiveEscrowsByUser(address _user, uint256 _offset, uint256 _limit) external view returns (uint256[] memory) {
        uint256 total = escrowCounter;
        uint256[] memory temp = new uint256[](total);
        uint256 count = 0;

        for (uint256 i = 1; i <= total && count < _offset + _limit; i++) {
            Escrow storage e = escrows[i];
            if ((e.client == _user || e.provider == _user) && (e.status == Status.FUNDED || e.status == Status.DISPUTED)) {
                if (count >= _offset) temp[count - _offset] = i;
                count++;
            }
        }

        uint256 resultSize = count > _offset ? (count - _offset > _limit ? _limit : count - _offset) : 0;
        uint256[] memory result = new uint256[](resultSize);
        for (uint256 i = 0; i < resultSize; i++) result[i] = temp[i];
        return result;
    }

    function getActiveEscrowCount(address _user) external view returns (uint256) {
        return activeEscrowsByUser[_user];
    }

    function canClaimTimeout(uint256 _escrowId) external view returns (bool) {
        Escrow storage e = escrows[_escrowId];
        return e.status == Status.FUNDED && block.timestamp > e.timeoutDate;
    }

    function tokenSymbol(address _token) external view returns (string memory) {
        return tokenConfigs[_token].symbol;
    }

    // Alias compatible avec la V2/V3 de l'ABI
    function tokenSymbols(address _token) external view returns (string memory) {
        return tokenConfigs[_token].symbol;
    }

    function allowedTokens(address _token) external view returns (bool) {
        return tokenConfigs[_token].allowed;
    }
}
