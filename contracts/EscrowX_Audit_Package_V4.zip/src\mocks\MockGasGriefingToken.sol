// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract MockGasGriefingToken is ERC20 {
    constructor() ERC20("Gas Griefer", "GRIEF") {
        _mint(msg.sender, 1000000 * 10**18);
    }

    // A malicious transfer that burns gas in a loop
    function transfer(address to, uint256 amount) public virtual override returns (bool) {
        uint256 startGas = gasleft();
        while (gasleft() > 100000) {
            uint256 dummy = startGas * 2;
        }
        return super.transfer(to, amount);
    }
}
