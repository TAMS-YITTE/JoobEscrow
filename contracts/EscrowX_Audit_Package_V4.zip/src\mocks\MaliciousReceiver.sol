// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "../UniversalServiceEscrow.sol";

// Contrat receiver malveillant qui revert à la réception
contract MaliciousReceiver {
    UniversalServiceEscrow public escrow;
    bool public attackMode = false;
    
    constructor(address _escrow) {
        escrow = UniversalServiceEscrow(_escrow);
    }
    
    function setAttackMode(bool _mode) external {
        attackMode = _mode;
    }
    
    receive() external payable {
        if (attackMode) revert("Blocked!");
    }
}
